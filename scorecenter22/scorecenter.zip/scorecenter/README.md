# COMP 20, Assignment 5: Scorecenter

## IMPLEMENTED
I have implemented a working index or homepage [/], a POST API [/submit.json], a GET API [/highscores.json], and a usersearch [/usersearch] feature. All work correctly, although all could be more visually appealing.

## COLLABORATION
I collaborated with Jessie Serrino, Tara Kola, and Cameron Jackson on this assignment.

## TIME SPENT
I spent approximately twelve to fifteen hours completing this assignment.
